#pragma once

// CMyData ���� ����Դϴ�.

class CMyData : public CObject 
{
	DECLARE_SERIAL(CMyData) 
public:
	CString m_str;
	bool m_bItalic, m_bUnder;
public:
	CMyData();
		CMyData(CString &str, bool It, bool Under) {
		m_str = str; 
		m_bItalic = It;
		m_bUnder = Under;
	}
	virtual ~CMyData();
	void Serialize(CArchive& ar); 
};

