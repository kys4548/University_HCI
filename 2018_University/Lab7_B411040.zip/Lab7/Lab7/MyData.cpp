// MyData.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Lab7.h"
#include "MyData.h"


// CMyData

CMyData::CMyData()
{
}

CMyData::~CMyData()
{
}

IMPLEMENT_SERIAL(CMyData, CObject, 1) 

void CMyData::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
		ar << m_bItalic << m_bUnder << m_str;
	else
		ar >> m_bItalic >> m_bUnder >> m_str;
}
// CMyData ��� �Լ�
