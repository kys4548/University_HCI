//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// hw3.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_hw3TYPE                     130
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_Q                            32782
#define ID_W                            32783
#define ID_E                            32784
#define ID_R                            32785
#define ID_T                            32786
#define ID_A                            32787
#define ID_S                            32788
#define ID_D                            32789
#define ID_F                            32790
#define ID_G                            32791
#define ID_H                            32792
#define ID_J                            32793
#define ID_K                            32794
#define ID_L                            32795
#define ID_Z                            32796
#define ID_X                            32797
#define ID_BUTTON32838                  32838

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32839
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
