
// hw3View.cpp : Chw3View Ŭ������ ����
//

#include "stdafx.h"
// SHARED_HANDLERS�� �̸� ����, ����� �׸� �� �˻� ���� ó���⸦ �����ϴ� ATL ������Ʈ���� ������ �� ������
// �ش� ������Ʈ�� ���� �ڵ带 �����ϵ��� �� �ݴϴ�.
#ifndef SHARED_HANDLERS
#include "hw3.h"
#endif

#include "hw3Doc.h"
#include "hw3View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Chw3View

IMPLEMENT_DYNCREATE(Chw3View, CView)

BEGIN_MESSAGE_MAP(Chw3View, CView)
	// ǥ�� �μ� �����Դϴ�.
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_CHAR()
//	ON_WM_KEYDOWN()
ON_WM_KEYDOWN()
ON_WM_LBUTTONDBLCLK()
END_MESSAGE_MAP()

// Chw3View ����/�Ҹ�

Chw3View::Chw3View()
{
	m_bDraw = FALSE;
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.

}

Chw3View::~Chw3View()
{
}

BOOL Chw3View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	//  Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.

	return CView::PreCreateWindow(cs);
}

// Chw3View �׸���

void Chw3View::OnDraw(CDC* pDC)
{
	Chw3Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	POSITION pos = pDoc->m_list.GetHeadPosition();
	while (pos != NULL){
		CPen pen;
		CBrush brush;
		CBrush brush1;
		pDoc->m_temp=pDoc->m_list.GetNext(pos);
		if (pDoc->m_temp.m_type != 4 && pDoc->m_temp.m_type != 5){

			switch (pDoc->m_temp.m_ptype){
			case 1:
				pen.CreatePen(PS_SOLID, 2, RGB(255, 0, 0));
				break;
			case 2:
				pen.CreatePen(PS_SOLID, 2, RGB(0, 255, 0));
				break;
			case 3:
				pen.CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
				break;
			default:
				break;
			}
		}
		else{
			pen.CreatePen(PS_DASH, 1, RGB(0, 0, 0));
		}

		switch (pDoc->m_temp.m_btype){
		case 1:
			brush.CreateSolidBrush(RGB(255, 0, 0));
			break;
		case 2:
			brush.CreateSolidBrush(RGB(0, 255, 0));
			break;
		case 3:
			brush.CreateSolidBrush(RGB(0, 0, 255));
			break;
		default:
			break;
		}
		switch (pDoc->m_temp.m_ftype){
		case 1:
			pDC->SetTextColor(RGB(255, 0, 0));
			break;
		case 2:
			pDC->SetTextColor(RGB(0, 255, 0));
			break;
		case 3:
			pDC->SetTextColor(RGB(0, 0, 255));
			break;

		}
		pDC->SelectObject(&pen);
		pDC->SelectObject(&brush);
		CRect rect;
		CPoint p1, p2;
		POSITION pos;
		switch (pDoc->m_temp.m_type){
		case 1:
			pDC->MoveTo(pDoc->m_temp.m_st.x, pDoc->m_temp.m_st.y);
			pDC->LineTo(pDoc->m_temp.m_ed.x, pDoc->m_temp.m_ed.y);
			break;
		case 2:
			rect.SetRect(pDoc->m_temp.m_st.x, pDoc->m_temp.m_st.y, pDoc->m_temp.m_ed.x, pDoc->m_temp.m_ed.y);
			rect.NormalizeRect();
			pDC->Rectangle(&rect);
			break;
		case 3:
			rect.SetRect(pDoc->m_temp.m_st.x, pDoc->m_temp.m_st.y, pDoc->m_temp.m_ed.x, pDoc->m_temp.m_ed.y);
			rect.NormalizeRect();
			pDC->Ellipse(&rect);
			break;
		case 4:
			rect.SetRect(pDoc->m_temp.m_st.x, pDoc->m_temp.m_st.y, pDoc->m_temp.m_st.x + 200, pDoc->m_temp.m_st.y + 20);
			pDC->Rectangle(&rect);
			brush1.CreateSolidBrush(RGB(255, 255, 255));
			pDC->SelectObject(&brush1);
			pDC->DrawText(pDoc->m_temp.m_str, &rect, DT_LEFT);
			break;
		case 5:
			pos = pDoc->m_temp.m_p.GetHeadPosition();
			while (pos != NULL){
				p1 = pDoc->m_temp.m_p.GetAt(pos);
				p2 = pDoc->m_temp.m_p.GetNext(pos);
				pDC->MoveTo(p1);
				pDC->LineTo(p2);
			}
			break;
		default:
			break;
		}

	}


	// TODO: ���⿡ ���� �����Ϳ� ���� �׸��� �ڵ带 �߰��մϴ�.
}


// Chw3View �μ�

BOOL Chw3View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// �⺻���� �غ�
	return DoPreparePrinting(pInfo);
}

void Chw3View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ��ϱ� ���� �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
}

void Chw3View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: �μ� �� ���� �۾��� �߰��մϴ�.
}


// Chw3View ����

#ifdef _DEBUG
void Chw3View::AssertValid() const
{
	CView::AssertValid();
}

void Chw3View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

Chw3Doc* Chw3View::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(Chw3Doc)));
	return (Chw3Doc*)m_pDocument;
}
#endif //_DEBUG


// Chw3View �޽��� ó����


void Chw3View::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	
	Chw3Doc* pDoc = GetDocument();
	CClientDC dc(this);
	CMyShape temp;
	if (pDoc->m_z == FALSE && pDoc->m_x == FALSE){
		switch (pDoc->m_temp.m_type){
		case 1:
		case 2:
		case 3:
			SetCapture();
			m_bDraw = true;
			pDoc->m_temp.m_st = point;
			pDoc->m_temp.m_ed = point;
			break;

		default:
			break;

		}
	}

	pDoc->SetModifiedFlag();
	CView::OnLButtonDown(nFlags, point);
}


void Chw3View::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	Chw3Doc* pDoc = GetDocument();
	CClientDC dc(this);
	CPen pen;
	CBrush brush;

	if (m_bDraw){
		switch (pDoc->m_temp.m_ptype){
		case 1:
			pen.CreatePen(PS_SOLID, 2, RGB(255, 0, 0));
			break;
		case 2:
			pen.CreatePen(PS_SOLID, 2, RGB(0, 255, 0));
			break;
		case 3:
			pen.CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
			break;
		default:
			break;
		}

		switch (pDoc->m_temp.m_btype){
		case 1:
			brush.CreateSolidBrush(RGB(255, 0, 0));
			break;
		case 2:
			brush.CreateSolidBrush(RGB(0, 255, 0));
			break;
		case 3:
			brush.CreateSolidBrush(RGB(0, 0, 255));
			break;
		default:
			break;
		}
		

		
		dc.SelectObject(&pen);
		dc.SelectObject(&brush);
		//dc.SelectStockObject(LTGRAY_BRUSH);

		dc.SetROP2(R2_NOTXORPEN);


		switch (pDoc->m_temp.m_type){
		case 1:
			dc.MoveTo(pDoc->m_temp.m_st);
			dc.LineTo(pDoc->m_temp.m_ed);
			pDoc->m_temp.m_ed = point;
			dc.MoveTo(pDoc->m_temp.m_st);
			dc.LineTo(pDoc->m_temp.m_ed);
			break;
		case 2:
			dc.Rectangle(pDoc->m_temp.m_st.x, pDoc->m_temp.m_st.y, pDoc->m_temp.m_ed.x, pDoc->m_temp.m_ed.y);
			pDoc->m_temp.m_ed = point;
			dc.Rectangle(pDoc->m_temp.m_st.x, pDoc->m_temp.m_st.y, pDoc->m_temp.m_ed.x, pDoc->m_temp.m_ed.y);
			break;
		case 3:
			dc.Ellipse(pDoc->m_temp.m_st.x, pDoc->m_temp.m_st.y, pDoc->m_temp.m_ed.x, pDoc->m_temp.m_ed.y);
			pDoc->m_temp.m_ed = point;
			dc.Ellipse(pDoc->m_temp.m_st.x, pDoc->m_temp.m_st.y, pDoc->m_temp.m_ed.x, pDoc->m_temp.m_ed.y);
			break;
		default:
			break;
		}
	}
	//pDoc->SetModifiedFlag();  �ϸ�ȵȴ�.
	CView::OnMouseMove(nFlags, point);
}


void Chw3View::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	Chw3Doc* pDoc = GetDocument();
	if (pDoc->m_z == FALSE && pDoc->m_x == FALSE){
		CMyShape temp;
		switch (pDoc->m_temp.m_type){
		case 1:
		case 2:
		case 3:
			m_bDraw = false;
			ReleaseCapture();
			temp = pDoc->m_temp;
			pDoc->m_list.AddTail(temp);
			break;
		case 4:
			pDoc->m_temp.m_str = "";
			pDoc->m_temp.m_st = point;
			CreateSolidCaret(2, 20);
			SetCaretPos(pDoc->m_temp.m_st);
			ShowCaret();
			temp = pDoc->m_temp;
			pDoc->m_list.AddTail(temp);
			break;
		case 5:
			temp.m_p.AddTail(point);
			


			break;
		default:
			break;
		}
		pDoc->SetModifiedFlag();
		Invalidate();

	}
	else{

		POSITION pos = pDoc->m_list.GetHeadPosition();

		while (pos != NULL){
			pDoc->m_temp = pDoc->m_list.GetAt(pos);
			CRect rect;
			rect.SetRect(pDoc->m_temp.m_st,pDoc->m_temp.m_ed);
			rect.NormalizeRect();

			if (rect.PtInRect(point)){
				a = pos;
				break;
			}
			pDoc->m_list.GetNext(pos);
		}
	}

	pDoc->SetModifiedFlag();
	Invalidate();
	CView::OnLButtonUp(nFlags, point);
}


void Chw3View::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	Chw3Doc* pDoc = GetDocument();
	// TODO: Add your message handler code here and/or call default
	if (pDoc->m_temp.m_type==4){
		pDoc->m_list.RemoveTail();
		DestroyCaret();
		// Backspace �Է� �� �� ������ ���ڸ� �����Ѵ�.
		if (nChar == _T('\b')){
			if (pDoc->m_temp.m_str.GetLength() > 0)
				pDoc->m_temp.m_str.Delete(pDoc->m_temp.m_str.GetLength() - 1);
		}
		// �� ���� ��쿡�� ���� �迭�� ���ڸ� �߰��Ѵ�.
		else{
			pDoc->m_temp.m_str.AppendChar(nChar);
		}
		CMyShape temp = pDoc->m_temp;
		pDoc->m_list.AddTail(temp);
		// �����Ͱ� �����Ǿ����� ��ť��Ʈ ��ü�� �˸���.
		
	}
	

	pDoc->SetModifiedFlag(); //������ �Ǿ �𸥴�. 

	// ���� ȭ���� �����Ѵ�.
	Invalidate();
	CView::OnChar(nChar, nRepCnt, nFlags);
}





void Chw3View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: Add your message handler code here and/or call default
	Chw3Doc* pDoc = GetDocument();
	if (pDoc->m_z == true || pDoc->m_x == true){
		pDoc->m_temp = pDoc->m_list.GetAt(a);

		if (pDoc->m_z == true){
			switch (nChar){
			case VK_LEFT:
				pDoc->m_temp.m_st.x -= 20;
				pDoc->m_temp.m_ed.x -= 20;
				break;
			case VK_RIGHT:
				pDoc->m_temp.m_st.x += 20;
				pDoc->m_temp.m_ed.x += 20;
				break;
			case VK_UP:
				pDoc->m_temp.m_st.y -= 20;
				pDoc->m_temp.m_ed.y -= 20;
				break;
			case VK_DOWN:
				pDoc->m_temp.m_st.y += 20;
				pDoc->m_temp.m_ed.y += 20;
				break;
			}
		}
		else if (pDoc->m_x == true){
			CRect rect;
			switch (pDoc->m_temp.m_type){
			case 1:
				break;
			case 2:
			case 3:
				rect.SetRect(pDoc->m_temp.m_st, pDoc->m_temp.m_ed);
				rect.NormalizeRect();
				pDoc->m_temp.m_st = rect.TopLeft();
				pDoc->m_temp.m_ed = rect.BottomRight();
				switch (nChar){
				case VK_UP:
						pDoc->m_temp.m_st.y -= 1;
						pDoc->m_temp.m_ed.y += 1;
						pDoc->m_temp.m_st.x -= 1;
						pDoc->m_temp.m_ed.x += 1;
					break;
				case VK_DOWN:
					if (pDoc->m_temp.m_st.x < pDoc->m_temp.m_ed.x && pDoc->m_temp.m_st.y < pDoc->m_temp.m_ed.y){
						pDoc->m_temp.m_st.y += 1;
						pDoc->m_temp.m_ed.y -= 1;
						pDoc->m_temp.m_st.x += 1;
						pDoc->m_temp.m_ed.x -= 1;
					}
					break;
				}
			}
		}
		pDoc->m_list.RemoveAt(a);
		CMyShape temp = pDoc->m_temp;
		pDoc->m_list.AddTail(temp);
		pDoc->SetModifiedFlag(); //������ �Ǿ �𸥴�. 

		 //���� ȭ���� �����Ѵ�.
		Invalidate();
	}


	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void Chw3View::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	Chw3Doc* pDoc = GetDocument();
	if (pDoc->m_temp.m_type == 5)
		pDoc->m_temp.m_p.AddTail(point);
	pDoc->SetModifiedFlag(); //������ �Ǿ �𸥴�. 

	//���� ȭ���� �����Ѵ�.
	Invalidate();
	CView::OnLButtonDblClk(nFlags, point);
}
