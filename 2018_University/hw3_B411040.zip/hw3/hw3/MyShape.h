#pragma once

// CMyShape ���� ����Դϴ�.

class CMyShape : public CObject
{
	DECLARE_SERIAL(CMyShape)
public:
	CPoint m_st,m_ed; 
	int m_type;
	int m_ptype, m_btype, m_ftype;
	CString m_str[100];
	CList <CPoint, CPoint&> m_p;
	
	CMyShape();
	CMyShape(const CMyShape& t);
	CMyShape& operator=(const CMyShape& t);
	virtual ~CMyShape();
	void Serialize(CArchive& ar);
};


