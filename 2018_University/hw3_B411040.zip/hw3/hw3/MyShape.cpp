// MyShape.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "hw3.h"
#include "MyShape.h"


// CMyShape

CMyShape::CMyShape()
{
	m_st.SetPoint(0, 0); m_ed.SetPoint(0, 0);
	m_type = m_ptype = m_btype = m_ftype = 0;
	m_str == "";
}
CMyShape::CMyShape(const CMyShape& t){
	*this = t;

}

CMyShape& CMyShape::operator=(const CMyShape& t){
	m_st = t.m_st;
	m_ed = t.m_ed;
	m_type = t.m_type;
	m_ptype = t.m_ptype;
	m_btype = t.m_btype;
	m_ftype = t.m_ftype; 
	m_str = t.m_str;

	POSITION pos = t.m_p.GetHeadPosition();
	while (pos != NULL){
		m_p.AddTail((CPoint)t.m_p.GetAt(pos));

		t.m_p.GetNext(pos);
	}
	return *this;
}
CMyShape::~CMyShape()
{
}
IMPLEMENT_SERIAL(CMyShape,CObject,1)



void CMyShape::Serialize(CArchive& ar){
	CObject::Serialize(ar);
	if (ar.IsStoring()){
		ar << m_st << m_ed  << m_type << m_ptype << m_btype << m_ftype << m_str;
		m_p.Serialize(ar);
		
	}
	else{
		ar >> m_st >> m_ed >> m_type >> m_ptype >> m_btype >> m_ftype >> m_str;
		m_p.Serialize(ar);
	}
}

// CMyShape ��� �Լ�
