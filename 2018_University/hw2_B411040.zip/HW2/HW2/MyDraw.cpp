#include "stdafx.h"
#include "MyDraw.h"


CMyDraw::CMyDraw()
{
}


CMyDraw::~CMyDraw()
{
}

void CMyDraw::SetRect(CRect rect){
	m_rect = rect;
}
CRect* CMyDraw::GetRect(){
	return &m_rect;
}

void CMyDraw::SetType(int type){
	m_type = type;
}

int CMyDraw::GetType(){
	return m_type;
}


CMyDraw& CMyDraw::operator=(const CMyDraw &t){
	m_rect = t.m_rect;
	m_type = t.m_type;

	return *this;
}