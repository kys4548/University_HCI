#pragma once
class CMyDraw
{
public:
	CMyDraw();
	~CMyDraw();

	void SetRect(CRect rect);
	void SetType(int type);

	CRect* GetRect();
	int GetType();

	CMyDraw& operator=(const CMyDraw &t);

private:
	CRect m_rect;
	int m_type;
};

