//B411040 �迵��
// CircleDoc.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "MDI.h"
#include "CircleDoc.h"


// CCircleDoc

IMPLEMENT_DYNCREATE(CCircleDoc, CDocument)

CCircleDoc::CCircleDoc()
{
}

BOOL CCircleDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	m_points.RemoveAll();
	m_pencolor = RGB(0, 255, 0);
	return TRUE;
}

CCircleDoc::~CCircleDoc()
{
}


BEGIN_MESSAGE_MAP(CCircleDoc, CDocument)
	ON_COMMAND(ID_CIRCLEMENU_PENCOLOR, &CCircleDoc::OnCirclemenuPencolor)
END_MESSAGE_MAP()


// CCircleDoc �����Դϴ�.

#ifdef _DEBUG
void CCircleDoc::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CCircleDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CCircleDoc serialization�Դϴ�.

void CCircleDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.
		ar << m_pencolor;
		m_points.Serialize(ar);
	}
	else
	{
		// TODO: ���⿡ �ε� �ڵ带 �߰��մϴ�.
		ar >> m_pencolor;
		m_points.Serialize(ar);
	}
}
#endif


// CCircleDoc �����Դϴ�.


void CCircleDoc::OnCirclemenuPencolor()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�
	CColorDialog dlg(m_pencolor);
	if (dlg.DoModal() == IDOK){
		m_pencolor = dlg.GetColor();
		SetModifiedFlag();
		UpdateAllViews(NULL);
	}
}
