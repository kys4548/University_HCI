//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Lab9.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_Lab9TYPE                    130
#define IDD_DIALOG1                     310
#define IDD_DIALOG2                     312
#define IDC_STR                         1000
#define IDC_FONT                        1001
#define IDAPPLY                         1004
#define IDC_CLEAR                       1006
#define ID_COLOR_TEXTCOLOR              32771
#define ID_COLOR_BACKGROUNDCOLOR        32772
#define ID_FONT_SELECTFONT              32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
