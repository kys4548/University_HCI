//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Lab12.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_Lab12TYPE                   130
#define ID_WINDOW_MANAGER               131
#define IDD_DIALOG1                     310
#define IDC_EDIT1                       1000
#define ID_WEB_SEARCH                   32771
#define ID_WEB_BACK                     32772
#define ID_WEB_FORWORD                  32773
#define ID_WEB_OPENFILE                 32774
#define ID_WEB_OPENFILE32775            32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        311
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
