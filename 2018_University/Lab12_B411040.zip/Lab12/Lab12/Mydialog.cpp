// Mydialog.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "Lab12.h"
#include "Mydialog.h"
#include "afxdialogex.h"


// CMydialog ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CMydialog, CDialogEx)

CMydialog::CMydialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMydialog::IDD, pParent)
	, m_url(_T(""))
{

}

CMydialog::~CMydialog()
{
}

void CMydialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_url);
}


BEGIN_MESSAGE_MAP(CMydialog, CDialogEx)
END_MESSAGE_MAP()


// CMydialog �޽��� ó�����Դϴ�.
