//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Lab6.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define ID_INDICATOR_POS                129
#define IDR_Lab6TYPE                    130
#define ID_32771                        32771
#define ID_COLOR_RED                    32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_COLOR_GREEN                  32775
#define ID_COLOR_BLUE                   32776
#define ID_32777                        32777
#define ID_Light                        32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
