// MyData.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "hw4.h"
#include "MyData.h"


// CMyData

IMPLEMENT_SERIAL(CMyData, CObject, 1);

CMyData::CMyData()
{
}

CMyData::~CMyData()
{
}

// CMyData ��� �Լ�
CMyData& CMyData::operator=(CMyData& md)
{
	m_name = md.m_name;
	m_firstNum = md.m_firstNum;
	m_lastNum = md.m_lastNum;
	m_sex = md.m_sex;
	m_age = md.m_age;
	m_addr = md.m_addr;

	return *this;
}

void CMyData::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << m_name << m_firstNum << m_lastNum << m_sex << m_age << m_addr;
	}
	else
	{
		ar >> m_name >> m_firstNum >> m_lastNum >> m_sex >> m_age >> m_addr;
	}
}