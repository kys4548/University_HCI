#pragma once

// CMyData ���� ����Դϴ�.



class CMyData : public CObject
{
	DECLARE_SERIAL(CMyData);
public:
	CMyData();
	virtual ~CMyData();
	void Serialize(CArchive& ar);
	CMyData& operator=(CMyData&);

	CString m_name;
	CString m_firstNum;
	CString m_lastNum;
	CString m_age;
	int m_sex;
	CString m_addr;
};


