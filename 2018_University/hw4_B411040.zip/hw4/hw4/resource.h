//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// hw4.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDD_HW4_FORM                    101
#define IDR_MAINFRAME                   128
#define IDR_hw4TYPE                     130
#define IDC_INPUTDATA                   1000
#define IDC_WHOLENUM                    1001
#define IDC_MANRADIO                    1002
#define IDC_WOMANRADIO                  1003
#define IDC_LIST                        1004
#define IDC_FIRSTNUM                    1005
#define IDC_HIMARK                      1006
#define IDC_AGE                         1007
#define IDC_NAME                        1008
#define IDC_EDIT3                       1009
#define IDC_SCROLLBAR1                  1010
#define IDC_p                           1011
#define IDC_BUTTON2                     1012
#define IDC_C                           1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
