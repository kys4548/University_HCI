#include "stdafx.h"
#include "MyDraw.h"


CMyDraw::CMyDraw()
{
}


CMyDraw::~CMyDraw()
{
}

void CMyDraw::SetStartPoint(CPoint st){
	m_start = st;
}

CPoint* CMyDraw::GetStartPoint(){
	return &m_start;
}
void CMyDraw::SetEndPoint(CPoint ed){
	m_end = ed;
}
CPoint* CMyDraw::GetEndPoint(){
	return &m_end;
}


CMyDraw& CMyDraw::operator=(const CMyDraw &t){
	m_start = t.m_start;
	m_end = t.m_end;

	return *this;
}