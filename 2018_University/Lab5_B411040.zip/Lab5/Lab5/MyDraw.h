#pragma once
class CMyDraw
{
public:
	CMyDraw();
	~CMyDraw();
	void SetStartPoint(CPoint st);
	void SetEndPoint(CPoint ed);
	CPoint* GetStartPoint();
	CPoint* GetEndPoint();
	CMyDraw& operator=(const CMyDraw &t);
private:
	CPoint m_start, m_end;
	int m_type;
};

